from flask import Flask, render_template, url_for, flash, redirect,session
from forms import LoginForm
from functools import wraps



app = Flask(__name__)
app.config['SECRET_KEY'] = '5791628bb0b13ce0c676dfde280ba245'


#Login required decorator
def login_required(f):
    @wraps(f)
    def wrap(*args,**kwargs):
        if 'logged_in' in session:
            return f(*args,**kwargs)
        else:
            flash("You need to login first.", 'danger')
            return redirect(url_for('login'))
    return wrap

@app.route("/", methods=['GET', 'POST'])
@app.route("/login/", methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        if form.username.data == 'admin' and form.password.data == 'admin':
            flash(f'Logged in!', 'success')
            session['logged_in'] = True
            return redirect(url_for('home'))
        else:
            session['logged_in'] = False
            flash('Login unsuccessful. Please check username and password', 'danger')
    return render_template('login.html', title = 'Login', form = form)

@app.route("/home/")
@login_required
def home():
    return render_template('home.html', title='Home')

@app.route("/pairwisecomparison/")
@login_required
def PCTool():
    return render_template('pairwisecomparison.html', title='Pairwise Comparison')

@app.route("/stylometricclustering/")
@login_required
def SCTool():
    return render_template('stylometricclustering.html', title='Stylometric Clustering')

@app.route("/help/")
def help():
    return render_template('help.html', title='Help')


if __name__ == '__main__':
    app.run(debug=True)